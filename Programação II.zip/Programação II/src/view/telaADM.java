package view;

import java.util.Scanner;

public class telaADM {
    public void exibindo(){
        Scanner sc = new Scanner(System.in);

        // Mantém o menu ativo até o administrador sair.
        while (true){
            // Apresenta as opções disponíveis.
            System.out.println("\n===== MENU =====" +
                    "\n1 - Adicionar filmes  " +
                    "\n2 - Criar sessão" +
                    "\n3 - Adicionar sala " +
                    "\n4 - SAIR" +
                    "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            // Executa a ação conforme a opção selecionada.
            switch (opcao){
                case "1":
                    // Exibe a tela de cadastro de filmes.
                    System.out.println("Tela para Adicionar filmes");
                    break;
                case "2":
                    // Exibe a tela de criação de sessões.
                    System.out.println("Tela para Criar sessão");
                    break;
                case "3":
                    // Exibe a tela de cadastro de salas.
                    System.out.println("Tela para Adicionar sala");
                    break;
                case "4":
                    // Encerra o menu de administração.
                    System.out.println("SAIR");
                    return;
            }
        }

    }
}
