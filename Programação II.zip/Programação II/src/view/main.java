package view;

import controller.ControllerUsuario;
import java.util.Scanner;
import model.DAO.usuario;

public class main {

    private ControllerUsuario controlUser;

    private void run(){
        // Permite ler os dados digitados pelo usuário.
        Scanner sc = new Scanner(System.in);

        // Cria o controlador e conecta ao banco de dados.
        this.controlUser = new ControllerUsuario();
        controlUser.conectaBD ("CinemaTatiana");

        // Encerra o programa se a conexão falhar.
        if (controlUser.getS() == null) {
            System.out.println("Não foi possível conectar ao banco!");
            sc.close();
            return;
        }

        // Mantém o menu funcionando até o usuário sair.
        while (true) {

            // Exibe as opções disponíveis.
            System.out.println("\n===== SISTEMA DE CINEMA =====" +
                               "\n1 - Criar conta " +
                               "\n2 - Entrar" +
                               "\n3 - Sair" +
                               "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            // Executa a opção escolhida.
            switch (opcao) {

                case "1":
                    // Solicita os dados para criar a conta.
                    System.out.println("Primeiro nome: ");
                    String priNome = sc.nextLine();

                    System.out.println("Sobrenome: ");
                    String sobNome = sc.nextLine();

                    System.out.println("Senha: ");
                    String senha= sc.nextLine();

                    System.out.println("Confirme a senha: ");
                    String confirSenha = sc.nextLine();

                    // Verifica se os campos obrigatórios estão preenchidos.
                    if (priNome.trim().isEmpty()
                            ||sobNome.trim().isEmpty()
                            || senha.trim().isEmpty()){
                        System.out.println("Preencha os campos!");
                    
                     // Verifica se as senhas são iguais.
                    } else if (!senha.equals(confirSenha)) {
                       System.out.println("As senhas não são iguais.");
                    } else {
                        // Cria o objeto que armazenará os dados do usuário.
                        usuario novoUser = new usuario();

                        novoUser.setPriNome(priNome.trim());
                        novoUser.setSobNome(sobNome.trim());
                        novoUser.setSenha(senha);
                        // Envia os dados para o controlador cadastrar o usuário.
                        // novoUser.setTipo("CLIENTE");
                        String resposta = controlUser.cadastrarUser(novoUser);

                        System.out.println(resposta);
                    }

                    break;

                case "2":
                    // Solicita os dados para realizar o login.
                    System.out.println("\n===== ENTRAR NA CONTA =====");

                    System.out.print("Primeiro nome: ");
                    String nomeLogin = sc.nextLine();

                    System.out.print("Sobrenome: ");
                    String sobreLogin = sc.nextLine();

                    System.out.print("Senha: ");
                    String senhaLogin = sc.nextLine();

                    // Verifica se todos os campos foram preenchidos.
                    if (nomeLogin.trim().isEmpty()
                            || sobreLogin.trim().isEmpty()
                            || senhaLogin.trim().isEmpty()) {

                        System.out.println("Preencha todos os campos!");

                    } else {
                        // Verifica as credenciais e obtém o tipo de usuário.
                        String tipo = controlUser.entrarConta(
                                nomeLogin.trim(),
                                sobreLogin.trim(),
                                senhaLogin
                        );

                        // Exibe o tipo de usuário retornado pelo banco.
                        System.out.println("Tipo retornado pelo banco: [" + tipo + "]");

                        // Abre a tela correspondente ao tipo de usuário.
                        switch (tipo){
                            case "CLIENTE":
                                // Acessa a tela principal do cliente.
                                System.out.println("Login cliente realizado");
                                telaPrincipal tela = new telaPrincipal();
                                tela.exibindo();
                                break;

                            case "ADMIN":
                                // Acessa a tela de administração.
                                System.out.println("Login ADM realizado");
                                telaADM tela2 = new telaADM();
                                tela2.exibindo();
                                break;
                        }
                    }

                    break;

                case "3":
                    // Encerra o sistema e fecha os recursos utilizados.
                    System.out.println("Sistema encerrado.");

                    try {
                        // Fecha a conexão com o banco de dados.
                        controlUser.getS().close();
                    } catch (Exception e) {
                        // Informa se ocorrer um erro ao fechar a conexão.
                        System.out.println("Erro ao fechar a conexão.");
                    }
                    
                    // Fecha o Scanner e encerra o programa.
                    sc.close();
                    return;
            }
        }
    }




    public static void main(String[] args) {new main().run();}
}