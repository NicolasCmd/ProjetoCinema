package view;
import java.util.Scanner;
public class telaPrincipal {
    public void exibindo(){
        Scanner sc = new Scanner(System.in);

        // Mantém o menu ativo até o usuário sair.
        while (true){
            // Apresenta as opções disponíveis.
            System.out.println("\n===== MENU PRINCIAL =====" +
                    "\n1 - Filmes disponiveis " +
                    "\n2 - Sessões disponiveis" +
                    "\n3 - Camprar ingresso" +
                    "\n4 - SAIR" +
                    "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            switch (opcao){
                case "1":
                    // Exibe a tela de consulta de filmes.
                    System.out.println("Tela para ver os filmes disponiveis");
                    break;
                case "2":
                    // Exibe a tela de consulta de sessões.
                    System.out.println("Tela para ver os sessões disponiveis");
                    break;
                case "3":
                    // Exibe a tela de compra de ingressos.
                    System.out.println("Tela para comprar ingressos");
                    break;
                case "4":
                    // Encerra o menu principal.
                    System.out.println("SAIR");
                    return;
            }
        }

    }
}
