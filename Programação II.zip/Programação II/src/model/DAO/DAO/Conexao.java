package model.DAO.DAO;

// Importa as classes necessárias para conexão com o banco de dados
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexao {

            // Armazena a conexão e o comando SQL
            private Connection Conn;
            private Statement s;

            // Construtor
            public Conexao(){}

            // Retorna a conexão com o banco de dados
            public Connection getConn() {
                return Conn;
            }

            // Retorna o objeto responsável por executar comandos SQL
            public Statement getS() {
                return s;
            }

            // Estabelece a conexão com o banco de dados informado
            public void connDB(String db){
                try {
                    String URL = "jdbc:postgresql://localhost:5432/"+db;
                    String user = "postgres";
                    String pwd = "galito";

                    /*Conectando ao Servidor de Banco de Dados*/
                    Class.forName("org.postgresql.Driver");
                    this.Conn = DriverManager.getConnection(URL, user, pwd);
                    this.s = this.Conn.createStatement();

                    System.out.println("BD Conectado");
                }catch(SQLException e){
                    // Exibe erros relacionados ao banco de dados
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    // Informa erro caso o driver não seja encontrado
                    throw new RuntimeException(e);
                }
            }
}




