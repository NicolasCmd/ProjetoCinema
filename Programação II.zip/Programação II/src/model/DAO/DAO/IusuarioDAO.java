package model.DAO.DAO;

// Importa a classe usuario
import model.DAO.usuario;

// Interface que define os métodos de acesso aos dados do usuário
public interface IusuarioDAO {

    // Define o metodo para cadastrar um novo usuário.
    public String cadastrarUser(String tabela, usuario novoUser);
    // Define o metodo para realizar o login de um usuário.
    public String entrarConta (String tabela, String nome,String sobre ,String senha);


}