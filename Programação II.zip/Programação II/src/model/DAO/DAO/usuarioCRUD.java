package model.DAO.DAO;

import model.DAO.usuario;

import java.sql.ResultSet;
import java.sql.Statement;

public class usuarioCRUD implements IusuarioDAO {

    // Implementa os métodos definidos na interface IusuarioDAO
    private Statement s;
    // variavel sera usada para executar o SQL
    // Statement = tipo de objeto que executa comandos SQL

    public usuarioCRUD(Statement s) {
        this.s = s;
    }
    // Recebe um Statement e o armazena no atributo da classe

    @Override
    public String cadastrarUser(String tabela, usuario novoUser) {
        // recebe a tabela e o objeto que tem os dados do usuario
        String SQL = "INSERT INTO " + tabela + " (primeiro_nome,sobre_nome,senha) VALUES ('" + novoUser.getPriNome() + "','"
                + novoUser.getSobNome() + "','" + novoUser.getSenha() + "')";
        // Monta o comando SQL para inserir os dados do usuário na tabela


        int linhasAfetadas = -1;
        // Inicializa a variável com -1 para indicar que a operação ainda não foi concluída com sucesso

        try {
            linhasAfetadas = s.executeUpdate(SQL);
            // Tenta executar o comando de inserção

        } catch (Exception e) {
            // Captura possíveis erros durante a execução do comando SQL
            e.printStackTrace();
        }
        return "codigo retorna: " + linhasAfetadas;
        // Retorna uma mensagem com a quantidade de linhas afetadas
        // Se retornar 1, uma linha foi inserida; se retornar -1, ocorreu um erro antes de obter o resultado


    }

    @Override
    public String entrarConta(String tabela, String nome, String sobre, String senha) {
        String SQL = "SELECT * FROM " + tabela + " WHERE primeiro_nome = '" + nome +
                "' AND sobre_nome = '" + sobre +
                "' AND senha = '" + senha + "';";
        // Monta uma consulta para localizar o usuário pelo nome, sobrenome e senha

        try { // Executa a consulta e armazena o resultado no ResultSet
            ResultSet rset = s.executeQuery(SQL);

            if (rset.next()) // Verifica se existe um registro correspondente à consulta
            {
                String tipo = rset.getString("tipo");
                return tipo;
            }
            rset.close();// Caso não entre no if fecha o ResultSet e envia a mensagem de erro
            return "Nome, sobrenome ou senha incorretos!";
        } catch (Exception e) {
            e.printStackTrace(); // exibe detalhes técnicos no console
            return "Erro";
        }
    }



}





