package model.DAO;

// Classe que representa um usuário do sistema
public class usuario {

    // Atributos que armazenam os dados do usuário
    private String priNome;
    private String sobNome;
    private String senha;
    private String tipo;

    // Construtor
    public usuario(){}

    // Retorna e define o primeiro nome
    public String getPriNome(){return priNome;}
    public void setPriNome(String priNome){this.priNome=priNome;}

    // Retorna e define o sobrenome
    public String getSobNome(){return sobNome;}
    public void setSobNome(String sobNome){this.sobNome=sobNome;}

    // Retorna e define a senha
    public String getSenha(){return senha;}
    public void setSenha(String senha) {this.senha = senha;}

    // Retorna e define o tipo de usuário
    public String getTipo(){return tipo;}
    public void setTipo(String tipo){this.tipo=tipo;}
}
