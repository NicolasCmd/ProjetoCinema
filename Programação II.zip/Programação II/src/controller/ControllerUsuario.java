
package controller;

import java.sql.Statement;
import model.DAO.DAO.Conexao;
import model.DAO.DAO.IusuarioDAO;
import model.DAO.DAO.usuarioCRUD;
import model.DAO.usuario;

public class ControllerUsuario {

    // Armazena a conexão usada para executar comandos SQL.
    private Statement s;

    // Define as operações de acesso aos dados do usuário.
    private IusuarioDAO dao;

    // Define o nome da tabela do banco de dados.
    private static final String tabela = "usuario";

    public ControllerUsuario() {
    }

    // Retorna o Statement da conexão.
    public Statement getS() {
        return s;
    }

    // Estabelece a conexão com o banco de dados.
    public void conectaBD(String db) {
        Conexao conn = new Conexao();
        conn.connDB(db);

        // Obtém o Statement da conexão.
        this.s = conn.getS();

        // Inicializa o DAO se a conexão for estabelecida.
        if (this.s != null) {
            this.dao = new usuarioCRUD(this.s);
        }
    }
    // Terá comentarios repetidos
    public String cadastrarUser(usuario novoUser) { // recebe as informações
        if (dao == null) { // verifica se o dao foi iniciado
            return "Banco de dados não conectado."; // Banco de dados não conectado.
        }
        return dao.cadastrarUser(tabela, novoUser); // Manda os dados para o DAO
    }

    public String entrarConta (String nome,String sobre ,String senha){ // recebe as informações
        if (dao==null){ // verifica se o dao foi iniciado
            return "Banco de dados não conectado.";
        }
        return dao.entrarConta(tabela, nome, sobre, senha); // Manda os dados para o DAO
    }

}
