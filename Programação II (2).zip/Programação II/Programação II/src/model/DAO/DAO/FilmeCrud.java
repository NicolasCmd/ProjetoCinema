package model.DAO.DAO;

import model.DAO.filme;

import java.sql.ResultSet;
import java.sql.Statement;

public class FilmeCrud implements IfilmeDAO {

    // Implementa os métodos definidos na interface IusuarioDAO
    private Statement s;
    // variavel sera usada para executar o SQL
    // Statement = tipo de objeto que executa comandos SQL

    public FilmeCrud(Statement s) {
        this.s = s;
    }
    // Recebe um Statement e o armazena no atributo da classe

    @Override
    public String BuscarFilme(String tabela, String nome) {
        String SQL = "SELECT * FROM " + tabela + " WHERE nome = %'" + nome + "'%;";
        // Monta uma consulta para localizar o usuário pelo nome, sobrenome e senha

        try { // Executa a consulta e armazena o resultado no ResultSet
            ResultSet rset = s.executeQuery(SQL);


            rset.close();// Caso não entre no if fecha o ResultSet e envia a mensagem de erro
            return "Filme não encontrado!";
        } catch (Exception e) {
            e.printStackTrace(); // exibe detalhes técnicos no console
            return "Erro";
        }
    }



}





