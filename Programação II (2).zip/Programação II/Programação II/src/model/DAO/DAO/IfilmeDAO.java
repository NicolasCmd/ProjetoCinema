package model.DAO.DAO;

// Importa a classe usuario
import model.DAO.filme;

// Interface que define os métodos de acesso aos dados do usuário
public interface IfilmeDAO {

    // Define o metodo para realizar o login de um usuário.
    public String BuscarFilme(String tabela, String nome);


}