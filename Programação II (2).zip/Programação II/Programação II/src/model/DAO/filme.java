package model.DAO;

// Classe que representa um usuário do sistema
public class filme {

    // Atributos que armazenam os dados do usuário
    private String id;
    private String nome;
    private String duracao;
    private String classificacao;

    // Construtor
    public filme(){}

    // Retorna e define o nome
    public String getNome(){return nome;}
    public void setNome(String nome){this.nome=nome;}

}
