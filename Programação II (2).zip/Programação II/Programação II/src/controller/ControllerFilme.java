
package controller;

import java.sql.Statement;
import model.DAO.DAO.IfilmeDAO;
public class ControllerFilme {

    // Armazena a conexão usada para executar comandos SQL.
    private Statement s;

    // Define as operações de acesso aos dados do usuário.
    private IfilmeDAO dao;

    // Define o nome da tabela do banco de dados.
    private static final String tabela = "filmes";

    public ControllerFilme() {
    }

    // Retorna o Statement da conexão.
    public Statement getS() {
        return s;
    }

    // Terá comentarios repetidos
    public String Buscar(String nome) { // recebe as informações
        if (dao == null) { // verifica se o dao foi iniciado
            return "Banco de dados não conectado."; // Banco de dados não conectado.
        }
        return dao.BuscarFilme(tabela, nome); // Manda os dados para o DAO
    }
}
