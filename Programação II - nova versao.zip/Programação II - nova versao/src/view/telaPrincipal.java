package view;
import java.util.Scanner;

import controller.ControllerFilme;
import model.DAO.filme;

public class telaPrincipal {

    Scanner sc = new Scanner(System.in);
    private ControllerFilme controlFilme;

    public void exibindo() {

        this.controlFilme = new ControllerFilme();
        controlFilme.conectaBD ("CinemaTatiana");

        // Encerra o programa se a conexão falhar.
        if (controlFilme.getS() == null) {
            System.out.println("Não foi possível conectar ao banco!");

            sc.close();
            return;
        }

        Scanner sc = new Scanner(System.in);
            while (true) {

                System.out.println(
                        "\n===== MENU PRINCIPAL ====="
                                + "\n1 - Filmes disponíveis"
                                + "\n2 - Sessões disponíveis"
                                + "\n3 - Comprar ingresso"
                                + "\n4 - Encontrar filme"
                                + "\n5 - Sair"
                                + "\nEscolha uma opção: "
                );

                String opcao = sc.nextLine().trim();

                switch (opcao) {

                    case "1":
                        System.out.println(
                                "Tela para ver os filmes disponíveis."
                        );
                        break;

                    case "2":
                        System.out.println(
                                "Tela para ver as sessões disponíveis."
                        );
                        break;

                    case "3":
                        System.out.println(
                                "Tela para comprar ingressos."
                        );
                        break;

                    case "4":
                        System.out.print(
                                "Digite o nome do filme: "
                        );

                        String nome = sc.nextLine().trim();

                        if (nome.isEmpty()) {
                            System.out.println(
                                    "Digite um nome válido."
                            );
                            break;
                        }

                        String resultado = controlFilme.Buscar(nome);

                        System.out.println("\n" + resultado);
                        break;

                    case "5":
                        System.out.println("Encerrando o sistema...");
                        return;

                    default:
                        System.out.println(
                                "Opção inválida. Escolha de 1 a 5."
                        );
                        break;
                }
            }
    }
}