
package model.DAO.DAO;

import java.sql.*;

public class FilmeCrud implements IfilmeDAO {

    private Statement s;

    public FilmeCrud(Statement s) {
        this.s = s;
    }

    @Override
    public String BuscarFilme(String tabela, String nome) {

        String sql = """
                SELECT id, nome, duracao, classificacao
                FROM filmes
                WHERE nome ILIKE ?
                ORDER BY nome
                """;

        StringBuilder resultado = new StringBuilder();

        try (PreparedStatement ps = s.getConnection()
                .prepareStatement(sql)) {

            ps.setString(1, "%" + nome.trim() + "%");

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    resultado.append("\nID: ")
                            .append(rs.getInt("id"));

                    resultado.append("\nNome: ")
                            .append(rs.getString("nome"));

                    resultado.append("\nDuração: ")
                            .append(rs.getString("duracao"));

                    resultado.append("\nClassificação: ")
                            .append(rs.getString("classificacao"));

                    resultado.append("\n----------------------\n");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        if (resultado.length() == 0) {
            return "Nenhum filme encontrado com esse nome.";
        }

        return resultado.toString();
    }
}
