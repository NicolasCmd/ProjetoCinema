package model.DAO;

public class filme {

    private int id;
    private String nome;
    private String duracao;
    private String classificacao;

    public filme() {
    }

    public filme(int id, String nome,
                 String duracao, String classificacao) {
        this.id = id;
        this.nome = nome;
        this.duracao = duracao;
        this.classificacao = classificacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }
}
