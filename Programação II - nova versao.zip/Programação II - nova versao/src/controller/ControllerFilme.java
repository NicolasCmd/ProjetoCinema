package controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import model.DAO.DAO.*;

public class ControllerFilme {

    private Statement s;

    // Define as operações de acesso aos dados do usuário.
    private IfilmeDAO daofilme;

    // Define o nome da tabela do banco de dados.
    private static final String tabela = "filmes";

    public ControllerFilme() {
    }

    // Retorna o Statement da conexão.
    public Statement getS() {
        return s;
    }

    // Estabelece a conexão com o banco de dados.
    public void conectaBD(String db) {
        Conexao conn = new Conexao();
        conn.connDB(db);

        // Obtém o Statement da conexão.
        this.s = conn.getS();

        // Inicializa o DAO se a conexão for estabelecida.
        if (this.s != null) {
            this.daofilme = new FilmeCrud(this.s);
        }
    }

    public String Buscar(String nome) {

        if (daofilme == null) {
            return "Banco de dados não conectado.";
        }

        if (nome == null || nome.trim().isEmpty()) {
            return "Digite o nome de um filme.";
        }

        return daofilme.BuscarFilme("filmes",nome.trim());
    }
}
