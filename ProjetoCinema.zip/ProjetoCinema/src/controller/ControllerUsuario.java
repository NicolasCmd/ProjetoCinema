
package controller;

import model.DAO.DAO.Conexao;
import model.DAO.DAO.IusuarioDAO;
import model.DAO.usuario;
import model.DAO.DAO.usuarioCRUD;

import java.sql.Statement;

public class ControllerUsuario {

    private Statement s;
    private IusuarioDAO dao;

    private static final String tabela = "usuario";

    public ControllerUsuario() {
    }

    public Statement getS() {
        return s;
    }

    public void conectaBD(String db) {
        Conexao conn = new Conexao();
        conn.connDB(db);

        this.s = conn.getS();

        if (this.s != null) {
            this.dao = new usuarioCRUD(this.s);
        }
    }
    // Terá comentarios repetidos
    public String cadastrarUser(usuario novoUser) { // recebe as informações
        if (dao == null) { // verifica se o dao foi iniciado
            return "Banco de dados não conectado."; // Banco de dados não conectado.
        }
        return dao.cadastrarUser(tabela, novoUser); // Manda os dados para o DAO
    }

    public String entrarConta (String nome,String sobre ,String senha){ // recebe as informações
        if (dao==null){ // verifica se o dao foi iniciado
            return "Banco de dados não conectado.";
        }
        return dao.entrarConta(tabela, nome, sobre, senha); // Manda os dados para o DAO
    }

}
