package view;

import java.util.Scanner;

public class telaADM {
    public void exibindo(){
        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("\n===== MENU =====" +
                    "\n1 - Adicionar filmes  " +
                    "\n2 - Criar sessão" +
                    "\n3 - Adicionar sala " +
                    "\n4 - SAIR" +
                    "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            switch (opcao){
                case "1":
                    System.out.println("Tela para Adicionar filmes");
                    break;
                case "2":
                    System.out.println("Tela para Criar sessão");
                    break;
                case "3":
                    System.out.println("Tela para Adicionar sala");
                    break;
                case "4":
                    System.out.println("SAIR");
                    return;
            }
        }

    }
}
