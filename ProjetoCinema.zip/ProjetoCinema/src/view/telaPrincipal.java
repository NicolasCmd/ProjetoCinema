package view;
import java.util.Scanner;
public class telaPrincipal {
    public void exibindo(){
        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("\n===== MENU RINCIAL =====" +
                    "\n1 - Filmes disponiveis " +
                    "\n2 - Sessões disponiveis" +
                    "\n3 - Camprar ingresso" +
                    "\n4 - SAIR" +
                    "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            switch (opcao){
                case "1":
                    System.out.println("Tela para ver os filmes disponiveis");
                    break;
                case "2":
                    System.out.println("Tela para ver os sessões disponiveis");
                    break;
                case "3":
                    System.out.println("Tela para comprar ingressos");
                    break;
                case "4":
                    System.out.println("SAIR");
                    return;
            }
        }

    }
}
