package view;

import controller.ControllerUsuario;
import model.DAO.usuario;
import java.util.Scanner;

public class main {

    private ControllerUsuario controlUser;

    private void run(){
        Scanner sc = new Scanner(System.in);

        this.controlUser = new ControllerUsuario();
        controlUser.conectaBD ("CinemaTatiana");

        if (controlUser.getS() == null) {
            System.out.println("Não foi possível conectar ao banco!");
            sc.close();
            return;
        }

        while (true) {

            System.out.println("\n===== SISTEMA DE CINEMA =====" +
                               "\n1 - Criar conta " +
                               "\n2 - Entrar" +
                               "\n3 - Sair" +
                               "\nEscolha uma opção: ");
            String opcao = sc.nextLine();

            switch (opcao) {

                case "1":

                    System.out.println("Primeiro nome: ");
                    String priNome = sc.nextLine();

                    System.out.println("Sobrenome: ");
                    String sobNome = sc.nextLine();

                    System.out.println("Senha: ");
                    String senha= sc.nextLine();

                    System.out.println("Confirme a senha: ");
                    String confirSenha = sc.nextLine();

                    if (priNome.trim().isEmpty()
                            ||sobNome.trim().isEmpty()
                            || senha.trim().isEmpty()){
                        System.out.println("Preencha os campos!");
                    } else if (!senha.equals(confirSenha)) {
                        System.out.println("As senhas não são a mesma");
                    } else {

                        usuario novoUser = new usuario();

                        novoUser.setPriNome(priNome.trim());
                        novoUser.setSobNome(sobNome.trim());
                        novoUser.setSenha(senha);
                        //novoUser.setTipo("CLIENTE");
                        String resposta = controlUser.cadastrarUser(novoUser);

                        System.out.println(resposta);
                    }

                    break;

                case "2":

                    System.out.println("\n===== ENTRAR NA CONTA =====");

                    System.out.print("Primeiro nome: ");
                    String nomeLogin = sc.nextLine();

                    System.out.print("Sobrenome: ");
                    String sobreLogin = sc.nextLine();

                    System.out.print("Senha: ");
                    String senhaLogin = sc.nextLine();

                    if (nomeLogin.trim().isEmpty()
                            || sobreLogin.trim().isEmpty()
                            || senhaLogin.trim().isEmpty()) {

                        System.out.println("Preencha todos os campos!");

                    } else {

                        String tipo = controlUser.entrarConta(
                                nomeLogin.trim(),
                                sobreLogin.trim(),
                                senhaLogin
                        );
                        System.out.println("Tipo retornado pelo banco: [" + tipo + "]");
                        switch (tipo){
                            case "CLIENTE":
                                System.out.println("Login cliente realizado");
                                telaPrincipal tela = new telaPrincipal();
                                tela.exibindo();
                                break;

                            case "ADMIN":
                                System.out.println("Login ADM realizado");
                                telaADM tela2 = new telaADM();
                                tela2.exibindo();
                                break;
                        }
                    }

                    break;

                case "3":

                    System.out.println("Sistema encerrado.");

                    try {
                        controlUser.getS().close();
                    } catch (Exception e) {
                        System.out.println("Erro ao fechar a conexão.");
                    }

                    sc.close();
                    return;
            }
        }
    }




    public static void main(String[] args) {new main().run();}
}