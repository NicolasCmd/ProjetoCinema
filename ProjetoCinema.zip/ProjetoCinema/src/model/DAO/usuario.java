package model.DAO;

public class usuario {
    private String priNome;
    private String sobNome;
    private String senha;
    private String tipo;

    public usuario(){}

    public String getPriNome(){return priNome;}
    public void setPriNome(String priNome){this.priNome=priNome;}

    public String getSobNome(){return sobNome;}
    public void setSobNome(String sobNome){this.sobNome=sobNome;}

    public String getSenha(){return senha;}
    public void setSenha(String senha) {this.senha = senha;}

    public String getTipo(){return tipo;}
    public void setTipo(String tipo){this.tipo=tipo;}
}
