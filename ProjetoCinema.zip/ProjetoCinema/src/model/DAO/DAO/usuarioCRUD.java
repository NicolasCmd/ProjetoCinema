package model.DAO.DAO;

import model.DAO.usuario;

import java.sql.ResultSet;
import java.sql.Statement;

public class usuarioCRUD implements IusuarioDAO {
    // implemntando a classe IusuarioDAO
    private Statement s;
    // variavel sera usada para executar o SQL
    // Statement = tipo de objeto que executa comandos SQL

    public usuarioCRUD(Statement s) {
        this.s = s;
    }
    // o Statement recebido é armazenado em s

    @Override
    public String cadastrarUser(String tabela, usuario novoUser) {
        // recebe a tabela e o objeto que tem os dados do usuario
        // a tabela é o nome da tabela ou seja usuario
        String SQL = "INSERT INTO " + tabela + " (primeiro_nome,sobre_nome,senha) VALUES ('" + novoUser.getPriNome() + "','"
                + novoUser.getSobNome() + "','" + novoUser.getSenha() + "')";
        // o SQL é o SQL
        // proxima parte pego no codigo da Tatiana
        int linhasAfetadas = -1;
        // -1, retornara a quantidade de linhas que foram afetadas, não sei se precisa, mas ta ai
        // não colocarei acento caso esteja se perguntando
        try { // ele tenta. Ele tenta executar a operação
            linhasAfetadas = s.executeUpdate(SQL);
            // o comando de executar executa o comando que vai modificar os dados
        } catch (Exception e) {
            // se ocorrer um erro entra no catch e o printStackTrace passa os detalhes tecnicos no console
            e.printStackTrace();
        }
        return "codigo retorna: " + linhasAfetadas;
        // se voltar 1 deu boa, se voltar -1 deu ruim, caso não perceba o gigangte texto vermelho


    }

    @Override
    public String entrarConta(String tabela, String nome, String sobre, String senha) {
        String SQL = "SELECT * FROM " + tabela + " WHERE primeiro_nome = '" + nome +
                "' AND sobre_nome = '" + sobre +
                "' AND senha = '" + senha + "';";
        // SQL SQL SQL SQL ROMULO
        try { // tenta executar a operação
            ResultSet rset = s.executeQuery(SQL); // envia a consulta para o banco e salva no objeto rset / cursor
            if (rset.next()) // tenta avançar o curso retornando TRUE ou FALSE, dependendo da resposta entra ou não no if
            {
                String tipo = rset.getString("tipo");
                return tipo;
            }
            rset.close();// Caso não entre no if fecha o ResultSet e envia a mensagem de erro
            return "Nome, sobrenome ou senha incorretos!";
        } catch (Exception e) {
            e.printStackTrace(); // exibe detalhes tecnicos no console, roubado da Tatiana
            return "Erro";
        }
    }



}





