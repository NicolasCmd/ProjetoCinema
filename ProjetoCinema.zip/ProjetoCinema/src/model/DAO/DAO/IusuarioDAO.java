package model.DAO.DAO;

import model.DAO.usuario;

public interface IusuarioDAO {
    public String cadastrarUser(String tabela, usuario novoUser);
    public String entrarConta (String tabela, String nome,String sobre ,String senha);


}
